import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function Home() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to My Life</Text>
      <Text>Love Quotes</Text>
      <Text>
        - Love is not about how much you say 'I love you,' but how much you can prove that it's true.
      </Text>
      <Text>Meeting you is a nice ACCIDENT</Text>
      <Text>{"You're not my FIRST, but you're probably the BEST that I HAVE"}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
});
