import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Picker } from '@react-native-picker/picker'; // Import Picker from '@react-native-picker/picker'
import AsyncStorage from '@react-native-async-storage/async-storage';

const RegisterForm = ({ navigation }) => {
  const [firstname, setFirstname] = useState('');
  const [lastname, setLastname] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [gender, setGender] = useState('');
  const [firstnameError, setFirstnameError] = useState(null);
  const [lastnameError, setLastnameError] = useState(null);
  const [nameError, setNameError] = useState(null);
  const [emailError, setEmailError] = useState(null);
  const [passwordError, setPasswordError] = useState(null);
  const [confirmPasswordError, setConfirmPasswordError] = useState(null);
  const [genderError, setGenderError] = useState(null);
  const [isRegistering, setIsRegistering] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isRegisterHovered, setIsRegisterHovered] = useState(false);

  const checkPasswordStrength = (password) => {
    if (password.length < 8) {
      return 'Weak';
    }
    if (/[!@#$%^&*()_+{}\[\]:;<>,.?~\\-]/.test(password) && /[A-Z]/.test(password)) {
      return 'Strong';
    }
    return 'Moderate';
  };

  const handleRegister = async () => {
    setFirstnameError(null);
    setLastnameError(null);
    setNameError(null);
    setEmailError(null);
    setPasswordError(null);
    setConfirmPasswordError(null);
    setGenderError(null);
    setIsRegistering(true);

    if (firstname === '') {
      setFirstnameError('Please enter your first name.');
      setIsRegistering(false);
      return;
    }
  
    if (lastname === '') {
      setLastnameError('Please enter your last name.');
      setIsRegistering(false);
      return;
    }
  
    if (email === '') {
      setEmailError('Please enter your email.');
      setIsRegistering(false);
      return;
    } else if (!email.endsWith('@gmail.com')) {
      setEmailError('Email must end @gmail.com');
      setIsRegistering (false);
      return;
    }
  
    if (password === '') {
      setPasswordError('Please enter your password.');
      setIsRegistering(false);
      return;
    }
  
    if (confirmPassword === '') {
      setConfirmPasswordError('Please confirm your password.');
      setIsRegistering(false);
      return;
    } else if (password !== confirmPassword) {
      setConfirmPasswordError('Passwords do not match.');
      setIsRegistering(false);
      return;
    }
  
    if (gender === '') {
      setGenderError('Please select your gender.');
      setIsRegistering(false);
      return;
    }
    await AsyncStorage.setItem('email', email);
    await AsyncStorage.setItem('password', password);

    setFirstname('');
    setLastname('');
    setName('');
    setEmail('');
    setPassword('');
    setConfirmPassword('');
    setGender('');

    setIsRegistering(false);

    if (
      firstname !== '' &&
      lastname !== '' &&
      email !== '' &&
      password !== '' &&
      confirmPassword !== '' &&
      email.endsWith('@gmail.com') &&
      password === confirmPassword &&
      gender !== ''
    ) {
      console.log(
        `Registering with First Name: ${firstname}, Last Name: ${lastname}, Email: ${email}, and Password: ${password}`
      );

      setTimeout(() => {
        setIsRegistering(false);
        navigation.navigate('Home');
      }, 3000);
    } else {
      setIsRegistering(false);
    }
  };

  const handlePasswordChange = (text) => {
    setPassword(text);
    const strength = checkPasswordStrength(text);
    setPasswordStrength(strength);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.label}>First Name</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your first name"
        value={firstname}
        onChangeText={(text) => setFirstname(text)}
      />
      {firstnameError && <Icon name="exclamation-triangle" size={20} color="red" />}
      {firstnameError && <Text style={styles.errorText}>{firstnameError}</Text>}

      <Text style={styles.label}>Last Name</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your last name"
        value={lastname}
        onChangeText={(text) => setLastname(text)}
      />
      {lastnameError && <Icon name="exclamation-triangle" size={20} color="red" />}
      {lastnameError && <Text style={styles.errorText}>{lastnameError}</Text>}

      <Text style={styles.label}>Email</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your email"
        value={email}
        onChangeText={(text) => setEmail(text)}
      />
      {emailError && <Icon name="exclamation-triangle" size={20} color="red" />}
      {emailError && <Text style={styles.errorText}>{emailError}</Text>}

      <Text style={styles.label}>Password</Text>
      <View style={styles.passwordInput}>
        <TextInput
          style={styles.input}
          placeholder="Enter your password"
          secureTextEntry={!showPassword}
          value={password}
          onChangeText={handlePasswordChange}
        />
        <Icon
          name={showPassword ? 'eye-slash' : 'eye'}
          size={20}
          color="#000"
          onPress={() => setShowPassword(!showPassword)}
        />
      </View>
      {passwordError && <Icon name="exclamation-triangle" size={20} color="red" />}
      {passwordError && <Text style={styles.errorText}>{passwordError}</Text>}

      <Text style={styles.label}>Confirm Password</Text>
      <View style={styles.passwordInput}>
        <TextInput
          style={styles.input}
          placeholder="Confirm your password"
          secureTextEntry={!showConfirmPassword}
          value={confirmPassword}
          onChangeText={(text) => setConfirmPassword(text)}
        />
        <Icon
          name={showConfirmPassword ? 'eye-slash' : 'eye'}
          size={20}
          color="#000"
          onPress={() => setShowConfirmPassword(!showConfirmPassword)}
        />
      </View>
      {confirmPasswordError && <Icon name="exclamation-triangle" size={20} color="red" />}
      {confirmPasswordError && <Text style={styles.errorText}>{confirmPasswordError}</Text>}

      {passwordStrength && (
        <Text style={styles.passwordStrength}>Password Strength: {passwordStrength}</Text>
      )}

      <Text style={styles.label}>Gender</Text>
      <Picker
        selectedValue={gender}
        onValueChange={(itemValue) => setGender(itemValue)}
        style={styles.picker}
      >
        <Picker.Item label="Select Gender" value="" />
        <Picker.Item label="Male" value="Male" />
        <Picker.Item label="Female" value="Female" />
        <Picker.Item label="Other" value="Other" />
      </Picker>
      {genderError && <Icon name="exclamation-triangle" size={20} color="red" />}
      {genderError && <Text style={styles.errorText}>{genderError}</Text>}

      {isRegistering ? (
        <ActivityIndicator size="large" color="#0000ff" />
      ) : (
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={handleRegister}
          onMouseEnter={() => setIsRegisterHovered(true)}
          onMouseLeave={() => setIsRegisterHovered(false)}
          style={[styles.registerButton, isRegisterHovered && styles.registerButtonHovered]}
        >
          <Text style={styles.buttonText}>REGISTER</Text>
        </TouchableOpacity>
      )}

      <View style={styles.loginContainer}>
        <Text style={styles.loginText}>Already have an account?</Text>
        <Button title="Login" color="blue" onPress={() => navigation.navigate('ZTECH Login')} />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flexGrow: 1,
    backgroundColor: '#00BFFF',
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
    fontWeight: 'bold',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 15,
    backgroundColor: 'white',
  },
  passwordInput: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 15,
    backgroundColor: 'white',
  },
  errorText: {
    color: 'red',
    marginBottom: 10,
  },
  passwordStrength: {
    marginBottom: 10,
  },
  loginContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  loginText: {
    marginRight: 10,
  },
  registerButton: {
    backgroundColor: 'blue',
    padding: 15,
    borderRadius: 5,
  },
  registerButtonHovered: {
    backgroundColor: 'darkblue',
  },
  buttonText: {
    color: '#B0C4DE',
    fontWeight: 'bold',
    fontSize: 18,
    textAlign: 'center',
  },
  picker: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 15,
    backgroundColor: 'white',
  },
});

export default RegisterForm;