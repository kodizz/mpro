import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import AsyncStorage from '@react-native-async-storage/async-storage';

const LoginForm = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState(null);
  const [passwordError, setPasswordError] = useState(null);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoginHovered, setIsLoginHovered] = useState(false);

  const handleLogin = async () => {
    // Reset any previous error messages.
    setEmailError(null);
    setPasswordError(null);

    if (email === '') {
      setEmailError('Please enter your email.');
    } else if (!email.endsWith('@gmail.com')) {
      setEmailError('Email must end @gmail.com');
    }

    if (password === '') {
      setPasswordError('Please enter your password.');
    }

    if (email !== '' && password !== '' && email.endsWith('@gmail.com')) {
      const storedEmail = await AsyncStorage.getItem('email');
      const storedPassword = await AsyncStorage.getItem('password');
    
      if (email === storedEmail && password === storedPassword) {
      setIsLoading(true); // Show the loading indicator
      // Implement your login logic here
      console.log(`Logging in with Email: ${email} and Password: ${password}`);

      // Add a 3-second delay before navigating to the home page
      setTimeout(() => {
        setIsLoading(false); // Hide the loading indicator
        navigation.navigate('Home');
      }, 3000); // 3000 milliseconds = 3 seconds
     } else {
    } setEmailError('User not registered or incorrect credentials.');
  }
  };
  

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Email</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter your email"
        value={email}
        onChangeText={text => setEmail(text)}
      />
      {emailError && <Text style={styles.errorText}>{emailError}</Text>}

      <Text style={styles.label}>Password</Text>
      <View style={styles.passwordInput}>
        <TextInput
          style={styles.input}
          placeholder="Enter your password"
          secureTextEntry={!showPassword}
          value={password}
          onChangeText={text => setPassword(text)}
        />
        <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
          <Icon name={showPassword ? 'eye-slash' : 'eye'} size={20} color="#333" />
        </TouchableOpacity>
      </View>
      {passwordError && <Text style={styles.errorText}>{passwordError}</Text>}

      {isLoading ? (
        <ActivityIndicator size="large" color="#0000ff" />
      ) : (
        <TouchableOpacity
        activeOpacity={0.7}
        onPress={handleLogin}
        onMouseEnter={() => setIsLoginHovered(true)}
        onMouseLeave={() => setIsLoginHovered(false)}
        style={[styles.loginButton, isLoginHovered && styles.loginButtonHovered]}
      >
        <Text style={styles.buttonText}>LOGIN</Text>
      </TouchableOpacity>
      )}

      <View style={styles.registerContainer}>
        <Text style={styles.registerText}>Don't have an account?</Text>
        <Button title="Register" color="blue" onPress={() => navigation.navigate('ZTECH Register')} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#00BFFF',
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
    fontWeight: 'bold',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 15,
    backgroundColor: 'white',
  },
  passwordInput: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 15,
    backgroundColor: 'white', 
  },
  errorText: {
    color: 'red',
    marginBottom: 10,
  },
  loginButton: {
    backgroundColor: 'blue',
    padding: 15,
    borderRadius: 5,
    width: '100%',
  },
  loginButtonHovered: {
    backgroundColor: 'darkblue', // Change this to your preferred color
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 18,
    textAlign: 'center',
  },
  registerContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  registerText: {
    marginRight: 10,
  },
});

export default LoginForm;
