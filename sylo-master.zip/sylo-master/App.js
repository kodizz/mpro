import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Login from './Authentication/Login/login';
import Register from './Authentication/Register/register';
import Home from './Homepage/HomePage';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="ZTECH Login">
        <Stack.Screen
          name="ZTECH Login"
          component={Login}
          options={{
            headerTitle: 'ZTECH',
            headerTitleAlign: 'center',
            headerStyle: {
              backgroundColor: '#00BFFF',
              borderBottomRightRadius: 10,
              borderBottomLeftRadius: 10,
            },
            headerTitleStyle: {
              color: 'black',
              fontSize: 24,
              fontWeight: 'bold',
              textTransform: 'uppercase',
              textDecorationLine: 'underline',
            },
          }}
        />
        <Stack.Screen
          name="ZTECH Register"
          component={Register}
          options={{
            headerTitle: 'ZTECH',
            headerTitleAlign: 'center',
            headerTitleStyle: {
              color: 'black',
              fontSize: 24,
              fontWeight: 'bold',
              textTransform: 'uppercase',
              textDecorationLine: 'underline',
            },
          }}
        />
        <Stack.Screen
          name="Home"
          component={Home}
          options={{
            headerTitle: 'Home',
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
